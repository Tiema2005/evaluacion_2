import datosExcel from "./productos.json";

// Imágenes referenciales antiguas: se reemplazan por ilustraciones locales
// para evitar fotografías que no corresponden al nombre del producto.
const IMAGENES_ANTERIORES = new Set([
    "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?auto=format&fit=crop&w=900&q=75",
    "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1472220625704-91e1462799b2?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&fit=crop&w=900&q=75",
    "https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=900&q=75",
    "https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1504148455328-c376907d081c?auto=format&fit=crop&w=900&q=75",
    "https://images.unsplash.com/photo-1504148455328-c376907d081c?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=900&q=75",
    "https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1513467655676-561b7d489a88?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1517581177682-a085bb7ffb15?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1530124566582-a618bc2615dc?auto=format&fit=crop&w=900&q=75",
    "https://images.unsplash.com/photo-1530124566582-a618bc2615dc?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1531835551805-16d864c8d311?auto=format&fit=crop&w=900&q=75",
    "https://images.unsplash.com/photo-1541976844346-f18aeac57b06?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1555963966-b7ae5404b6ed?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1558002038-1055907df827?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1558426118-c307dfb7d7bd?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1558904541-efa843a96f01?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1562259949-e8e7689d7828?auto=format&fit=crop&w=900&q=75",
    "https://images.unsplash.com/photo-1562259949-e8e7689d7828?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1563453392212-326f5e854473?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1565793298595-6a879b1d9492?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1566228015668-4c45dbc4e2f5?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1572896344187-0d2f6a1d4b31?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1572981779307-38b8cabb2407?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1581093450021-4a7360e9a6df?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1581094794329-c8112a89af12?auto=format&fit=crop&w=900&q=75",
    "https://images.unsplash.com/photo-1581147036324-c1c8f404c4f4?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1584622781564-1d987ba08046?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1585704032915-c3400ca199e7?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1586864387789-628af9feed72?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1589939705384-5185137a7f0f?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1590274853856-f22d5ee3d228?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1609205341474-1868c20d4ba9?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1612832021020-92d8f5f1eb65?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1615874959474-d609969a20ed?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1617576683096-00fc8eecb3af?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1621607512022-6aecc4fed814?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1621847468510-11959e0e50b7?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1621905251918-48416bd8575a?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1621905252507-b35492cc74b4?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1626082876116-6c505720b0f0?auto=format&fit=crop&w=900&q=80"
]);

const CODIGOS_CATALOGO = new Set(
    datosExcel["Catálogo de Productos"].slice(2).map(
        (producto) => producto["FERRETERÍA LOS MAESTROS"]
    )
);

export function obtenerImagenProducto(producto) {
    if (!producto) {
        return "/producto-sin-imagen.svg";
    }

    const imagen = typeof producto.imagen === "string" ? producto.imagen.trim() : "";

    // Se conserva cualquier foto personalizada que no sea una referencia antigua.
    if (imagen && !IMAGENES_ANTERIORES.has(imagen)) {
        return imagen;
    }

    // El catálogo original tiene una ilustración local específica por código.
    if (CODIGOS_CATALOGO.has(producto.codigo)) {
        return `/productos/${producto.codigo}.svg`;
    }

    return "/producto-sin-imagen.svg";
}
